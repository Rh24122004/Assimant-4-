<?php
session_start();
include 'db.php';
if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
        if(password_verify($password, $row['password'])){
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['name'];
            header("Location: dashboard.php");
        }else{
            $error = "كلمة المرور خاطئة";
        }
    }else{
        $error = "المستخدم غير موجود";
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>تسجيل الدخول</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>body{background:#f8f9fa;} .container{max-width:500px; margin-top:50px;}</style>
</head>
<body>
<div class="container bg-white p-4 rounded shadow">
<h2 class="mb-4 text-center">تسجيل الدخول</h2>
<?php if(isset($error)){ echo "<div class='alert alert-danger'>$error</div>"; } ?>
<form method="post">
<div class="mb-3">
<label>الايميل</label>
<input type="email" name="email" class="form-control" required>
</div>
<div class="mb-3">
<label>كلمة المرور</label>
<input type="password" name="password" class="form-control" required>
</div>
<button type="submit" name="login" class="btn btn-success w-100">تسجيل الدخول</button>
</form>
<p class="mt-3 text-center"><a href="register.php">إنشاء حساب جديد</a></p>
</div>
</body>
</html>
