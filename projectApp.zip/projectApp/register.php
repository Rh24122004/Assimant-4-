<?php
include 'new_db.php';
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (name,email,password) VALUES ('$name','$email','$password')";
    if($conn->query($sql)){
        echo "<div class='alert alert-success'>تم إنشاء الحساب بنجاح. <a href='login.php'>تسجيل الدخول</a></div>";
    }else{
        echo "<div class='alert alert-danger'>خطأ: ".$conn->error."</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>إنشاء حساب</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>body{background:#f8f9fa;} .container{max-width:500px; margin-top:50px;}</style>
</head>
<body>
<div class="container bg-white p-4 rounded shadow">
<h2 class="mb-4 text-center">إنشاء حساب جديد</h2>
<form method="post">
<div class="mb-3">
<label>الاسم</label>
<input type="text" name="name" class="form-control" required>
</div>
<div class="mb-3">
<label>الايميل</label>
<input type="email" name="email" class="form-control" required>
</div>
<div class="mb-3">
<label>كلمة المرور</label>
<input type="password" name="password" class="form-control" required>
</div>
<button type="submit" name="submit" class="btn btn-primary w-100">إنشاء الحساب</button>
</form>
<p class="mt-3 text-center"><a href="login.php">تسجيل الدخول</a></p>
</div>
</body>
</html>
