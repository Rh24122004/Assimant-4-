<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>creat Account</title>
</head>
<body>
    <center>
    <h1> Hello on website</h1>
    <form action="creat Account_manager_teeacher.php" method ="Post" >

    <input type= "text" name= "name" placecholder="name">
    <br>
    <input type="email" name= "email" placecholder="email">
    <br>
    <input type="password" name= "password" placecholder="password">
    <br>
    manager
    <input type="radio" name= "type" value="manager">
    teacher
    <input type="radio" name= "type" value="teacher">
    <input type="submit" value= "Creat" name="Create_account">
    </form>

    </center>
    

    
</body>
</html>