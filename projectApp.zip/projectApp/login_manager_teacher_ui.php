<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
</head>
<body>
    <center>
        <h1>hello in login page</h1>
        <form action="" method="Post">
            <label email></label>
            <input type="email" name="email">
            <br>
            <label password></label>
            <input type="password" name="password">
            <br>
            <input type="submit" name="login" value="login">


        </form>
    </center>
    
</body>
</html>