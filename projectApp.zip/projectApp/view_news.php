<?php
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: login.php"); }
include 'new_db.php';

$result = $conn->query("
SELECT news.*, categories.name AS category_name, users.name AS user_name 
FROM news 
JOIN categories ON news.category_id = categories.id 
JOIN users ON news.user_id = users.id
WHERE deleted = 0
");
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>عرض الأخبار</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>img{max-width:100px;}</style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-4">
<h2>جميع الأخبار</h2>
<table class="table table-bordered table-striped">
<thead class="table-dark">
<tr>
<th>ID</th>
<th>العنوان</th>
<th>الفئة</th>
<th>الكاتب</th>
<th>الصورة</th>
<th>تعديل</th>
<th>حذف</th>
</tr>
</thead>
<tbody>
<?php while($row = $result->fetch_assoc()){ ?>
<tr>
<td><?= $row['id'] ?></td>
<td><?= $row['title'] ?></td>
<td><?= $row['category_name'] ?></td>
<td><?= $row['user_name'] ?></td>
<td><?php if($row['image']!=""){ ?><img src="<?= $row['image'] ?>"><?php } ?></td>
<td><a href="edit_news.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">تعديل</a></td>
<td><a href="delete_news.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">حذف</a></td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
</body>
</html>
