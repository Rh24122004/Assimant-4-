<?php
session_start();
if(!isset($_SESSION['user_id'])){ header("Location: login.php"); }
include 'new_db.php';

$categories = $conn->query("SELECT * FROM categories");

if(isset($_POST['submit'])){
    $title = $_POST['title'];
    $category_id = $_POST['category_id'];
    $details = $_POST['details'];
    $user_id = $_SESSION['user_id'];

    $image = "";
    if(isset($_FILES['image']) && $_FILES['image']['name'] != ""){
        $image = "uploads/".time()."_".$_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], $image);
    }

    $sql = "INSERT INTO news (title, category_id, details, image, user_id) VALUES ('$title','$category_id','$details','$image','$user_id')";
    if($conn->query($sql)){
        $success = "تم إضافة الخبر بنجاح";
    }else{
        $error = "خطأ: ".$conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>إضافة خبر</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-4">
<h2>إضافة خبر جديد</h2>
<?php if(isset($success)){ echo "<div class='alert alert-success'>$success</div>"; } ?>
<?php if(isset($error)){ echo "<div class='alert alert-danger'>$error</div>"; } ?>
<form method="post" enctype="multipart/form-data">
<div class="mb-3">
<label>عنوان الخبر</label>
<input type="text" name="title" class="form-control" required>
</div>
<div class="mb-3">
<label>الفئة</label>
<select name="category_id" class="form-select" required>
<option value="">اختر الفئة</option>
<?php while($cat = $categories->fetch_assoc()){ ?>
<option value="<?= $cat['id'] ?>"><?= $cat['name'] ?></option>
<?php } ?>
</select>
</div>
<div class="mb-3">
<label>تفاصيل الخبر</label>
<textarea name="details" class="form-control" rows="5" required></textarea>
</div>
<div class="mb-3">
<label>صورة الخبر</label>
<input type="file" name="image" class="form-control">
</div>
<button type="submit" name="submit" class="btn btn-success">إضافة الخبر</button>
</form>
</div>
</body>
</html>
