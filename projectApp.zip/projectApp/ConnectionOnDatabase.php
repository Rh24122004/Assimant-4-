<?php

$connetion = new mysqli("localhost", "root", "", "new_db");

if($connetion->error == true){
    echo "connetion fail";
}else{
    echo "connected";
}

?>