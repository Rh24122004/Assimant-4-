<?php
include"connetiononOnDatabase.php";

if($connetion->error ==false){

    if(isset($_POST["creat_account"])){
        $name =$_POST ["name"];
        $email =$_POST ["email"];
        $password =$_POST ["password"];
        $type =$_POST ["type"];

        $sql = "INSERT INTO admins(name,email,password,type)
                      VALUES('$name' , '$email', $password', $type')";
        $result = $connetion->query($sql);
        if($result==true){
            echo"insertion done";
        }else{
            echo"fail"
        }
    }

}
?>